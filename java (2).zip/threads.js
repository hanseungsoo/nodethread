let async = require('async');
let myTCP =  require('./TCPClient.js');
let functions = [];

let sessionCount = 50;
let loop = 2;
let str_data ='aaaaabbbbbeeeffgghhhhiijjkkllmmnnqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq';
let startTime = null;
let finishTime = null;
let dev = false;

for(let i = 0; i < sessionCount; i++){
  functions.push(function(callback){

    startTime = new Date().getTime();
    let client = myTCP.getConnection(i,callback, 'result'+i);
    if(dev)
      console.log('Send : ' + str_data)
    myTCP.writeData(client, startTime,str_data);
    //callback(null,'result'+i);

  });
}
for(let i = 0; i < loop; i++){
  async.parallel(functions,
               function(err,results){
                         if(err) console.log(err);
                         //console.log('Result : ' + results);
                        //  finishTime = new Date().getTime();
                        //  let temp = finishTime - startTime;
                        //  console.log('# - Loop Finish : ' + temp.toString() + 'ms');
                               // handle resultC
                    }
  );

}



/*
async.waterfall([
  function(callback){
    async.parallel(functions,
                 function(err,results){
                           if(err) console.log(err);
                           console.log('Result : ' + results);
                                 // handle resultC
                      }
    );
  },
]
*/
